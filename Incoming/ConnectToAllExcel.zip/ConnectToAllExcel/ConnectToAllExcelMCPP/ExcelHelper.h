
#pragma once

// This file will contain only Managed Code

void ManagedFunction();