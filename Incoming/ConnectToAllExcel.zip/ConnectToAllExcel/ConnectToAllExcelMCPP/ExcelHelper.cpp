


#include "stdafx.h"
#include "ExcelHelper.h"

#include "uExcelHelper.h"

#include <Windows.h>
#include <OleAcc.h>
#include <tchar.h>

#pragma comment(lib, "oleacc.lib")

#using <mscorlib.dll>
using namespace System;
using namespace Microsoft::Office::Interop::Excel;
using namespace System::Runtime::InteropServices;
//#define Excel Microsoft::Office::Interop::Excel


[DllImport("ole32.dll", EntryPoint="IIDFromString")]
extern "C" int _cdecl IIDFromString2(
				[MarshalAs(UnmanagedType::LPWStr)] System::String ^lpsz,
				UUID *lpiid);

[DllImport("Oleacc.dll", EntryPoint="AccessibleObjectFromWindow")]
extern "C" int AccessibleObjectFromWindow2(
				int hwnd,
				unsigned int dwObjectID,
				//System::Guid iid,
				UUID *lpiid,
				Microsoft::Office::Interop::Excel::Window ^%window_ptr);

void GetWorkbooks(HWND hWndXLMain)
{

	// Test area
	// IIDFromString
	
	//LPOLESTR lpsz = OLESTR("{00020400-0000-0000-C000-000000000046}");
	//UUID iid;
	//int result = IIDFromString(lpsz, &iid);

/*	System::String ^mString = gcnew System::String("{00020400-0000-0000-C000-000000000046}");
	System::Guid ^lpiid = gcnew System::Guid();
	UUID iid2;
	result = IIDFromString2(mString, &iid2);
	*/
	HWND hWndDesk = FindWindowEx(hWndXLMain, 0, _T("XLDESK"), NULL);

	if (hWndDesk != 0)
	{
		HWND hWnd = FindWindowEx(hWndDesk, 0, NULL, NULL);
		
		while (hWnd != 0)
		{
			LPTSTR lpClassName = new TCHAR[100];
			//LPWSTR lpClassName = new WCHAR[100];
			ZeroMemory(lpClassName, 100*sizeof(TCHAR));

			GetClassName(hWnd, lpClassName, 100);

			if (_tcscmp(lpClassName, _T("EXCEL7")) == 0)
			{
				UUID iid;
				LPOLESTR lpsz = OLESTR("{00020400-0000-0000-C000-000000000046}");
				IIDFromString(lpsz, &iid);

				//System::String ^myString = gcnew System::String("Hello World");

				Microsoft::Office::Interop::Excel::Window ^window = nullptr;
				HRESULT hResult = AccessibleObjectFromWindow2((int)hWnd, OBJID_NATIVEOM, &iid, window);
				Microsoft::Office::Interop::Excel::Application ^app = window->Application;
				Microsoft::Office::Interop::Excel::Worksheet ^wkSheet = (Microsoft::Office::Interop::Excel::Worksheet ^)window->ActiveSheet;
				System::String ^sheetName = wkSheet->Name;
			}
			hWnd = FindWindowEx(hWndDesk, hWnd, NULL, NULL);
		}
	}
}

void ManagedFunction()
{
	HWND hWndXLMain = FindWindowEx(0, 0, _T("XLMAIN"), NULL);

	while (hWndXLMain != 0) 
	{
		GetWorkbooks (hWndXLMain);
		hWndXLMain = FindWindowEx(0, hWndXLMain, _T("XLMAIN"), NULL);
	}

	System::Environment::Exit(0);
	int delay=0;
}

//
//#using <mscorlib.dll>
//
//using namespace System;
//using namespace System::Text;
//using namespace System::Runtime::InteropServices;
//using namespace Microsoft::Office::Interop::Excel;
//#define Excel Microsoft::Office::Interop::Excel


/*
#include "stdafx.h"
#include "ExcelHelper.h"







[DllImport("user32.dll")]
extern "C" int _cdecl FindWindowEx(int hwndParent, int hwndChildAfter, String ^lpszClass, String ^lpszWindow);

[DllImport("user32.dll")]
extern "C" int _cdecl GetClassName(int hWnd, StringBuilder ^lpClassName, int maxCount);

[DllImport("ole32.dll")]
extern "C" int _cdecl IIDFromString(String ^lpsz, struct myGuid *lpiid);

[DllImport("oleacc.dll")]
extern "C" int _cdecl AccessibleObjectFromWindow(int hWnd, unsigned int dwObjectID, struct myGuid *lpiid, Excel::Window ^ptr);

Excel::Application ^GetExcelObjectFromHwnd(int hWnd)
{
	String ^iid = gcnew String("{00020400-0000-0000-C000-000000000046}");
	struct myGuid g3;
	g3.Data1 = 0x20400;
	g3.Data2 = 0;
	g3.Data3 = 0;
	for (int i=0; i < 8; i++)
		g3.Data4[i] = 0;
	g3.Data4[0] = 0xC0;
	g3.Data4[7] = 0x46;

	String ^s = "{00020400-0000-0000-C000-000000000046}";
	//IntPtr ip = Marshall::StringToBSTR(s);
	int result = IIDFromString(iid, &g3);
	System::Guid ^g = gcnew System::Guid(0x00020400, 0, 0, 0xC0, 0, 0, 0, 0, 0, 0, 0x46);

	const unsigned int OBJID_NATIVEOM = 0xFFFFFFF0;
	Excel::Window ^window_ptr = nullptr;
	int hResult = AccessibleObjectFromWindow(hWnd, OBJID_NATIVEOM, &g3, window_ptr);

	return nullptr;
}

void iterateOverAllExcelWindows()
{
	String ^myString = gcnew System::String("All Excel Windows: \n");
	int hWndMain = FindWindowEx (0, 0, gcnew System::String("XLMAIN"), nullptr);

	myUnamagedFunction(hWndMain);

	while (hWndMain != 0)
	{
		// START GetWorkBooks
		int hWndDesk = FindWindowEx(hWndMain, 0, gcnew System::String("XLDESK"), nullptr);
		if (hWndDesk != 0)
		{
			int hWnd = FindWindowEx(hWndDesk, 0, nullptr, nullptr);
			while (hWnd != 0)
			{
				StringBuilder ^strText = gcnew StringBuilder(100, 100);
				int lngRet = GetClassName(hWnd, strText, 100);
				String ^myString = strText->ToString();
				if (myString->CompareTo( "EXCEL7" ) == 0)
				{
					Excel::Application ^app = GetExcelObjectFromHwnd(hWnd);
					hWnd = 0;
				} else {
					hWnd = FindWindowEx(hWndDesk, 0, nullptr, nullptr);
				}				
			}
		}
		// END
		hWndMain = FindWindowEx (0, hWndMain, gcnew System::String("XLMAIN"), nullptr);
	}

	int j2 = 99;
	//IntPtr hWndMain = WindowsAPI.FindWindowEx(IntPtr.Zero, IntPtr.Zero, "XLMAIN", null);
}
*/
/*
#pragma unmanaged

#include "stdafx.h"
#include "ExcelHelper.h"

#include <Windows.h>
#include <stdio.h>
#include <tchar.h>
#include <OleAcc.h>

HRESULT AutomationWrap(int autoType, VARIANT *pvResult, IDispatch *pDisp, LPOLESTR ptName, int cArgs...)
{
    // Begin variable-argument list...
    va_list marker;
    va_start(marker, cArgs);
    if(!pDisp) {
//        MessageBox(NULL, "NULL IDispatch passed to AutoWrap()", "Error", 0x10010);
        _exit(0);
    }

    // Variables used...
    DISPPARAMS dp = { NULL, NULL, 0, 0 };
    DISPID dispidNamed = DISPID_PROPERTYPUT;
    DISPID dispID;
    HRESULT hr;
    char buf[200];
    char szName[200];

    
    // Convert down to ANSI
    WideCharToMultiByte(CP_ACP, 0, ptName, -1, szName, 256, NULL, NULL);
    
    // Get DISPID for name passed...
    hr = pDisp->GetIDsOfNames(IID_NULL, &ptName, 1, LOCALE_USER_DEFAULT, &dispID);
    if(FAILED(hr)) {
        sprintf(buf, "IDispatch::GetIDsOfNames(\"%s\") failed w/err 0x%08lx", szName, hr);
//        MessageBox(NULL, buf, "AutoWrap()", 0x10010);
        _exit(0);
        return hr;
    }
    
    // Allocate memory for arguments...
    VARIANT *pArgs = new VARIANT[cArgs+1];
    // Extract arguments...
    for(int i=0; i<cArgs; i++) {
        pArgs[i] = va_arg(marker, VARIANT);
    }
    
    // Build DISPPARAMS
    dp.cArgs = cArgs;
    dp.rgvarg = pArgs;
    
    // Handle special-case for property-puts!
    if(autoType & DISPATCH_PROPERTYPUT) {
        dp.cNamedArgs = 1;
        dp.rgdispidNamedArgs = &dispidNamed;
    }
    
    // Make the call!
    hr = pDisp->Invoke(dispID, IID_NULL, LOCALE_SYSTEM_DEFAULT, autoType, &dp, pvResult, NULL, NULL);
    if(FAILED(hr)) {
        sprintf(buf, "IDispatch::Invoke(\"%s\"=%08lx) failed w/err 0x%08lx", szName, dispID, hr);
        //MessageBox(NULL, buf, _T("AutoWrap()"), 0x10010);
        _exit(0);
        return hr;
    }
    // End variable-argument section...
    va_end(marker);
    
    delete [] pArgs;
    
    return hr;
}

IDispatch *GetWorkbooks(HWND hWndXLMain)
{
	//CoInitialize(NULL);

	HWND hWndDesk = FindWindowEx(hWndXLMain, 0, _T("XLDESK"), NULL);

	if (hWndDesk != 0)
	{
		HWND hWnd = FindWindowEx(hWndDesk, 0, NULL, NULL);
		
		while (hWnd != 0)
		{
			LPTSTR lpClassName = new TCHAR[100];
			//LPWSTR lpClassName = new WCHAR[100];
			ZeroMemory(lpClassName, 100*sizeof(TCHAR));

			GetClassName(hWnd, lpClassName, 100);

			if (_tcscmp(lpClassName, _T("EXCEL7")) == 0)
			{
				UUID iid;
				LPOLESTR lpsz = OLESTR("{00020400-0000-0000-C000-000000000046}");
				IIDFromString(lpsz, &iid);

				IDispatch *pDisp;
				HRESULT hResult = AccessibleObjectFromWindow(hWnd, OBJID_NATIVEOM, IID_IDispatch, (void**)&pDisp);
				//ManagedFunction();

				VARIANT v1;
				VariantInit(&v1);
				AutomationWrap(DISPATCH_PROPERTYGET, &v1, pDisp, L"Parent", 0);
				LPDISPATCH pExcelApp = v1.pdispVal;
				//pExcelApp->Release();
				
				pDisp->Release();
				return pExcelApp;
			}
			hWnd = FindWindowEx(hWndDesk, hWnd, NULL, NULL);
		}
	}
	return NULL;
}

void myUnamagedFunction()
{
	HWND hWndXLMain = FindWindowEx(0, 0, _T("XLMAIN"), NULL);

	while (hWndXLMain != 0) 
	{
		IDispatch *pExcelApp = GetWorkbooks(hWndXLMain);
//		return pExcelApp;
		hWndXLMain = FindWindowEx(0, hWndXLMain, _T("XLMAIN"), NULL);
	}
}

/*
void GetWorkbooks(HWND hWndXLMain)
{
	CoInitialize(NULL);

	HWND hWndDesk = FindWindowEx(hWndXLMain, 0, _T("XLDESK"), NULL);

	if (hWndDesk != 0)
	{
		HWND hWnd = FindWindowEx(hWndDesk, 0, NULL, NULL);
		
		while (hWnd != 0)
		{
			LPTSTR lpClassName = new TCHAR[100];
			//LPWSTR lpClassName = new WCHAR[100];
			ZeroMemory(lpClassName, 100*sizeof(TCHAR));

			GetClassName(hWnd, lpClassName, 100);

			if (_tcscmp(lpClassName, _T("EXCEL7")) == 0)
			{
				std::cout << "Window: 0x" << hWnd;
				UUID iid;
				LPCOLESTR lpsz = OLESTR("{00020400-0000-0000-C000-000000000046}");
				IIDFromString(lpsz, &iid);

				IDispatch *pDisp;
				HRESULT hResult = AccessibleObjectFromWindow(hWnd, OBJID_NATIVEOM, IID_IDispatch, (void**)&pDisp);

				VARIANT v1;
				VariantInit(&v1);
				AutomationWrap(DISPATCH_PROPERTYGET, &v1, pDisp, L"Parent", 0);
				LPDISPATCH pExcelApp = v1.pdispVal;
				//pDisp->Release();

				//VARIANT v2;
				//VariantInit(&v2);
				//AutomationWrap(DISPATCH_PROPERTYGET, &v2, pExcelApp, L"Workbooks", 0);
				//LPDISPATCH pExcelWorkbooks = v2.pdispVal;

				VARIANT v3;
				VariantInit(&v3);
				AutomationWrap(DISPATCH_PROPERTYGET, &v3, pExcelApp, L"Name", 0);
				LPDISPATCH pCount = v3.pdispVal;

				std::cout << "\nGot UUID: " << iid.Data1;
			}
			hWnd = FindWindowEx(hWndDesk, hWnd, NULL, NULL);
		}
	}
}

*/