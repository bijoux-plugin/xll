
#include "stdafx.h"
#include "uExcelHelper.h"

void unmanaged_function()
{

}