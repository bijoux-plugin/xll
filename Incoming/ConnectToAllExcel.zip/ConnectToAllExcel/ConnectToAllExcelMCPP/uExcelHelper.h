
#pragma once

void unmanaged_function();