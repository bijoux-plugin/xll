﻿using System;
using System.Text;
using System.Windows.Forms;
using Microsoft.Office.Core;
using Microsoft.Office.Interop.Excel;
using System.Collections;
using System.Reflection;

// Code is based on the following link:
//
// http://blogs.officezealot.com/whitechapel/archive/2005/04/10/4514.aspx
//

namespace ConnectToAllExcel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private const String addinName1 = "calypso2excel.xll";
        private const String addinName2 = "crib.xll";

        private void Form1_Load(object sender, EventArgs e)
        {
            IterateOverAllExcelInstances(DelegateMethodQueryAll);
        }

        private void btnDisableAll_Click(object sender, EventArgs e)
        {
            IterateOverAllExcelInstances(DelegateMethodDisableAll);
        }

        private void btnEnableAll_Click(object sender, EventArgs e)
        {
            IterateOverAllExcelInstances(DelegateMethodEnableAll);
        }

        private void btnAddToolbarButton_Click(object sender, EventArgs e)
        {
            IterateOverAllExcelInstances(DelegateMethodAddToolbarAll);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            IEnumerator iEnum = allAddedControls.GetEnumerator();
            while (iEnum.MoveNext())
            {
                this.Controls.Remove((System.Windows.Forms.TextBox)iEnum.Current);
            }
            allAddedControls = new ArrayList();
            txtTop = 12;

            IterateOverAllExcelInstances(DelegateMethodQueryAll);
        }

        private void IterateOverAllExcelInstances(InstanceAction action)
        {
            IntPtr hWndMain = WindowsAPI.FindWindowEx(IntPtr.Zero, IntPtr.Zero, "XLMAIN", null);

            while (hWndMain != IntPtr.Zero)
            {
                ExcelHelper.GetWorkBooks(hWndMain, action);
                hWndMain = WindowsAPI.FindWindowEx(IntPtr.Zero, hWndMain, "XLMAIN", null);
            }
        }

        public delegate void InstanceAction(Microsoft.Office.Interop.Excel.Application app);
        private static void DelegateMethodEnableAll(Microsoft.Office.Interop.Excel.Application app)
        {
            System.Collections.IEnumerator iEnum = app.AddIns.GetEnumerator();

            while (iEnum.MoveNext())
            {
                AddIn addIn = (AddIn)iEnum.Current;
                if ((addIn.Name.CompareTo(addinName1) == 0) || (addIn.Name.CompareTo(addinName2) == 0))
                {
                    addIn.Installed = true;
                }
            }
        }

        private static void DelegateMethodAddToolbarAll(Microsoft.Office.Interop.Excel.Application app)
        {
            IEnumerator iEnum = app.CommandBars.GetEnumerator();
            while (iEnum.MoveNext()) {
                CommandBar commandBar = (CommandBar)iEnum.Current;
                if (commandBar.Name.Equals("My Command Bar 3")) {
                    commandBar.Delete();
                    break;
                }
            }

            CommandBar cb = app.CommandBars.Add("My Command Bar 3", Microsoft.Office.Core.MsoBarPosition.msoBarTop, false, true);
            cb.Visible = true;

            CommandBarButton cbButton = (CommandBarButton)cb.Controls.Add(MsoControlType.msoControlButton, Type.Missing, Type.Missing, Type.Missing, true);
            cbButton.Style = MsoButtonStyle.msoButtonCaption;
            cbButton.Click += new _CommandBarButtonEvents_ClickEventHandler(buttonHelper);
            cbButton.Caption = "Reconnect";
            cbButton.FaceId = 122;
            cbButton.Width = 100;
            cbButton.Picture = null;

            CommandBarComboBox cbDropdown = (CommandBarComboBox)cb.Controls.Add(MsoControlType.msoControlDropdown, Type.Missing, Type.Missing, Type.Missing, true);
            cbDropdown.AddItem("tocrb01.cibg.tdbank.ca:6000 - OK", Type.Missing);
            cbDropdown.AddItem("tocrb02.cibg.tdbank.ca:6000 - Disconnected", Type.Missing);
            cbDropdown.AddItem("tocrb03.cibg.tdbank.ca:6000", Type.Missing);
            cbDropdown.AddItem("tocrb04.cibg.tdbank.ca:6000", Type.Missing);
            cbDropdown.ListIndex = 3;
            

            cbDropdown.Change += new _CommandBarComboBoxEvents_ChangeEventHandler(dropDownTestClick);
            cbDropdown.Width = 200;
        }

        public static void buttonHelper(Microsoft.Office.Core.CommandBarButton vsoButton, ref bool newValue)
        {
            //MessageBox.Show("NewValue: " + newValue);
        }

        public static void dropDownTestClick(Microsoft.Office.Core.CommandBarComboBox vsoButton)
        {
            //MessageBox.Show("Text=" + vsoButton.Text + ", ListIndex" + vsoButton.ListIndex);
        }

        private static void DelegateMethodDisableAll(Microsoft.Office.Interop.Excel.Application app)
        {
            System.Collections.IEnumerator iEnum = app.AddIns.GetEnumerator();

            while (iEnum.MoveNext())
            {
                AddIn addIn = (AddIn)iEnum.Current;
                if ((addIn.Name.CompareTo(addinName1) == 0) || (addIn.Name.CompareTo(addinName2) == 0))
                {
                    addIn.Installed = false;
                }
            }
        }

        private void DelegateMethodQueryAll(Microsoft.Office.Interop.Excel.Application app)
        {
            Boolean hasCRIB = ExcelHelper.isCRIBInstalled(app);
            Boolean cribIsLoaded = ExcelHelper.isCRIBRunning(app);
            AddEntry(app.Workbooks[1].Name, hasCRIB, cribIsLoaded);
        }

        private int txtTop = 12;
        private const int txtLeft = 114;
        private const int txtWidth = 300;

        private void AddEntry(String instanceName, Boolean hasCRIB, Boolean cribIsLoaded)
        {
            System.Windows.Forms.TextBox textBox = new System.Windows.Forms.TextBox();
            textBox.Location = new System.Drawing.Point(txtLeft, txtTop);
            textBox.Size = new System.Drawing.Size(txtWidth, 23);
            textBox.Text = instanceName + ", CRIB: " + hasCRIB + ", LOADED: " + cribIsLoaded;
            textBox.Visible = true;
            txtTop += 12 + 23;
            this.Controls.Add(textBox);
            allAddedControls.Add(textBox);
        }

        private ArrayList allAddedControls = new ArrayList();
    }
}