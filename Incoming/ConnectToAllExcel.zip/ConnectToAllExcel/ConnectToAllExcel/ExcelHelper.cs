﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Office.Interop.Excel;

namespace ConnectToAllExcel
{
    public class ExcelHelper
    {
        private const String addinName1 = "calypso2excel.xll";
        private const String addinName2 = "crib.xll";

        public static Boolean isCRIBInstalled(Microsoft.Office.Interop.Excel.Application app)
        {
            System.Collections.IEnumerator iEnum = app.AddIns.GetEnumerator();

            while (iEnum.MoveNext())
            {
                AddIn addIn = (AddIn)iEnum.Current;
                if ((addIn.Name.CompareTo(addinName1) == 0) || (addIn.Name.CompareTo(addinName2) == 0))
                {
                    return true;
                }
            }
            return false;
        }

        public static Boolean isCRIBRunning(Microsoft.Office.Interop.Excel.Application app)
        {
            System.Collections.IEnumerator iEnum = app.AddIns.GetEnumerator();

            while (iEnum.MoveNext())
            {
                AddIn addIn = (AddIn)iEnum.Current;
                if ((addIn.Name.CompareTo(addinName1) == 0) || (addIn.Name.CompareTo(addinName2) == 0))
                {
                    return addIn.Installed;
                }
            }
            return false;
        }

        public static Microsoft.Office.Interop.Excel.Application GetExcelObjectFromHwnd(IntPtr hWnd)
        {
            string iid = "{00020400-0000-0000-C000-000000000046}";
            Guid g = new Guid();
            int result = WindowsAPI.IIDFromString(iid, ref g);
            byte[] bArray = g.ToByteArray();

            const uint OBJID_NATIVEOM = 0xFFFFFFF0;

            Microsoft.Office.Interop.Excel.Window window_ptr = null;
            int hREsult = WindowsAPI.AccessibleObjectFromWindow(hWnd, OBJID_NATIVEOM, ref g, ref window_ptr);
            Microsoft.Office.Interop.Excel.Application app = window_ptr.Application;
            Microsoft.Office.Interop.Excel.Worksheet wkSheet = (Worksheet)window_ptr.ActiveSheet;
            String test = wkSheet.Name;
            return app;
        }

        public static void GetWorkBooks(IntPtr hWndMain, Form1.InstanceAction action)
        {
            IntPtr hWndDesk = WindowsAPI.FindWindowEx(hWndMain, IntPtr.Zero, "XLDESK", null);

            if (hWndDesk != IntPtr.Zero)
            {
                IntPtr hWnd = WindowsAPI.FindWindowEx(hWndDesk, IntPtr.Zero, null, null);

                while (hWnd != IntPtr.Zero)
                {
                    StringBuilder strText = new StringBuilder(100, 100);

                    int lngRet = WindowsAPI.GetClassName(hWnd, strText, 100);
                    if (strText.ToString().Equals("EXCEL7"))
                    {
                        Microsoft.Office.Interop.Excel.Application app = ExcelHelper.GetExcelObjectFromHwnd(hWnd);
                        action(app);
                        return;
                    }
                    hWnd = WindowsAPI.FindWindowEx(hWndDesk, hWnd, null, null);
                }
            }
        }
    }
}