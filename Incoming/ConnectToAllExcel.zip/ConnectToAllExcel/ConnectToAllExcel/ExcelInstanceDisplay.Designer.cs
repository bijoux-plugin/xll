﻿namespace ConnectToAllExcel
{
    partial class ExcelInstanceDisplay
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEnableDisable = new System.Windows.Forms.Button();
            this.lblAddInLocation = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnEnableDisable
            // 
            this.btnEnableDisable.Location = new System.Drawing.Point(3, 3);
            this.btnEnableDisable.Name = "btnEnableDisable";
            this.btnEnableDisable.Size = new System.Drawing.Size(64, 37);
            this.btnEnableDisable.TabIndex = 0;
            this.btnEnableDisable.UseVisualStyleBackColor = true;
            // 
            // lblAddInLocation
            // 
            this.lblAddInLocation.AutoSize = true;
            this.lblAddInLocation.Location = new System.Drawing.Point(73, 15);
            this.lblAddInLocation.Name = "lblAddInLocation";
            this.lblAddInLocation.Size = new System.Drawing.Size(79, 13);
            this.lblAddInLocation.TabIndex = 1;
            this.lblAddInLocation.Text = "AddIn Location";
            this.lblAddInLocation.Click += new System.EventHandler(this.label1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(167, 72);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 2;
            // 
            // ExcelInstanceDisplay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblAddInLocation);
            this.Controls.Add(this.btnEnableDisable);
            this.Name = "ExcelInstanceDisplay";
            this.Size = new System.Drawing.Size(441, 164);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnEnableDisable;
        private System.Windows.Forms.Label lblAddInLocation;
        private System.Windows.Forms.TextBox textBox1;
    }
}
